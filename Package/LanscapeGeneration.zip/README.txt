================ INSTALATION ================

- Extract to a folder
- Move extracted folder to 'Plugins' folder within project root folder (Create new folder if there's no Plugins folder)
- Restart Unreal Editor

================ CONTROL VARIABLE ================

Configuration
	Width and Length: Size of heightmap that will generate. Should be the same to ULandscape Resolution (verts).
	Seed: Accept any value between 1000000000 and -1000000000. This value will be use for every randomization (except the Raddomize Seed button).

Noise Configuration
Add irregularity
	Lacunarity: Affect frequency. Higher value, more hill and valley.
	Persistence: Affect amplitude, Higher value, higer hill and lower valley.

Mountain Generation
	Mountain N: how many mountain will generate. Uses same configuration.
	
	L-System
	Generate ridgeline by rewriting text according to given set of rules. Character will be replace with new character(s) based on given rules. Each character tell the program how to generate the line(s).
	F: go forward, use peak and radius as given; D: go forward, use 0.1 peak and radius; L: lowest point; P: peak point; +: turn right x degree; -: turn left x degree; []: branching; E: End of 'D' line.
		Axiom: starting text. MUST INCLUDE L...L, ...F..., ...P... .
		Iteration: how many time text should be rewritten.
		Line length: determine how long 'go forward'.
		Min and max turn angle: determine x in turning.
	
	Midpoint Displacement
	Generate ridgeline elevation.
		Displacement smooth: higher value, less subtle elevation changes.
		Displacement loop: higher value, more elevation changes.
	
	Mountain gradient
	Generate overall elevation.
		Peak: highest point of the mountain.
		Radius: mountain size.
		Fill degree: set higher if theres 'gap' in the mountain. Too high value resulting in cone-like mountain.
		Skew: skew mountain to left (negative) or right (positive).