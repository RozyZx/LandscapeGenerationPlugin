================ INSTALATION ================

- Extract to a folder
- Move extracted folder to 'Plugins' folder within project root folder (Create new folder if there's no Plugins folder)
- Restart Unreal Editor